import 'package:flutter/material.dart';

class QuestionnaireScreen extends StatefulWidget {
  const QuestionnaireScreen({super.key});

  @override
  State<QuestionnaireScreen> createState() => _QuestionnaireScreenState();
}

class _QuestionnaireScreenState extends State<QuestionnaireScreen> {
  final _formKey = GlobalKey<FormState>();

  // Variables for form fields (if needed)
  String age = '';
  String gender = '';

  // New list of fashion interests for a fashion app
  final List<_InterestItem> _interests = [
    _InterestItem(title: "Streetwear", imageAsset: 'assets/streetwear.jpg'),
    _InterestItem(title: "Casual", imageAsset: 'assets/casual.jpg'),
    _InterestItem(title: "Formal", imageAsset: 'assets/formal.jpg'),
    _InterestItem(title: "Athleisure", imageAsset: 'assets/athleisure.jpg'),
    _InterestItem(title: "Vintage", imageAsset: 'assets/vintage.jpg'),
    _InterestItem(title: "Bohemian", imageAsset: 'assets/bohemian.jpg'),
    _InterestItem(title: "Luxury", imageAsset: 'assets/luxury.jpg'),
    _InterestItem(title: "Minimalist", imageAsset: 'assets/minimalist.jpg'),
    _InterestItem(title: "Trendy", imageAsset: 'assets/trendy.jpg'),
    _InterestItem(title: "Designer", imageAsset: 'assets/designer.jpg'),
  ];

  int get _selectedCount =>
      _interests.where((interest) => interest.selected).length;

  bool get _canContinue => _selectedCount >= 5;

  void _toggleInterest(int index) {
    setState(() {
      _interests[index].selected = !_interests[index].selected;
    });
  }

  void _continue() {
    if (_canContinue) {
      Navigator.pushReplacementNamed(context, '/home');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least 5 styles')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      // Optionally add an AppBar if desired
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                const Text(
                  'Discover Your Fashion Style!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Select at least 5 styles to customize your feed',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 16),

                // Expanded Interests Grid
                Expanded(
                  child: GridView.builder(
                    itemCount: _interests.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemBuilder: (context, index) {
                      final interest = _interests[index];
                      return _buildInterestItem(interest, index);
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Continue Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _canContinue ? _continue : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      disabledBackgroundColor: Colors.white24,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: Text(
                      'Continue',
                      style: TextStyle(
                        fontSize: 16,
                        color: _canContinue ? Colors.black : Colors.white60,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Build dropdown question widget
  Widget _buildDropdownQuestion(String question, List<String> options,
      String? selectedValue, Function(String?) onSaved) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          question,
          style: const TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          value: selectedValue,
          items: options
              .map(
                (option) => DropdownMenuItem(
                  value: option,
                  child: Text(
                    option,
                    style: const TextStyle(color: Colors.black),
                  ),
                ),
              )
              .toList(),
          onChanged: (value) {},
          onSaved: onSaved,
          validator: (value) =>
              value == null || value.isEmpty ? 'This field is required' : null,
          hint: const Text(
            'Please Select',
            style: TextStyle(color: Colors.white),
          ),
        ),
      ],
    );
  }

  // Build each interest grid item
  Widget _buildInterestItem(_InterestItem interest, int index) {
    final isSelected = interest.selected;

    return GestureDetector(
      onTap: () => _toggleInterest(index),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: Colors.white12,
        ),
        child: Stack(
          children: [
            // Use a placeholder color if no image asset is provided.
            Positioned.fill(
              child: interest.imageAsset.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.asset(
                        interest.imageAsset,
                        fit: BoxFit.cover,
                      ),
                    )
                  : Container(color: Colors.white24),
            ),
            // Overlay to improve text visibility
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  color: isSelected
                      ? Colors.black.withOpacity(0.5)
                      : Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
            // Centered title and check icon when selected
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    interest.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                  if (isSelected) ...[
                    const SizedBox(height: 4),
                    const Icon(
                      Icons.check_circle,
                      color: Colors.white,
                      size: 20,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Model for a fashion interest item
class _InterestItem {
  final String title;
  final String imageAsset;
  bool selected;

  _InterestItem({
    required this.title,
    required this.imageAsset,
    this.selected = false,
  });
}
