import 'package:flutter/material.dart';

class TrendingPage extends StatelessWidget {
  // Mark the list literal as const to satisfy the const constructor requirements.
  final List<String> trendingItems = const [
    'Trending Item 1',
    'Trending Item 2',
    'Trending Item 3',
    'Trending Item 4',
    'Trending Item 5',
  ];

  const TrendingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Trending',
          style: Theme.of(context)
              .textTheme
              .titleLarge
              ?.copyWith(color: Colors.white),
        ),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Colors.black,
      body: ListView.builder(
        itemCount: trendingItems.length,
        itemBuilder: (context, index) {
          return Card(
            color: Colors.grey[900],
            child: ListTile(
              leading: const Icon(Icons.trending_up, color: Colors.white),
              title: Text(
                trendingItems[index],
                style: Theme.of(context)
                    .textTheme
                    .bodyLarge
                    ?.copyWith(color: Colors.white),
              ),
            ),
          );
        },
      ),
    );
  }
}
