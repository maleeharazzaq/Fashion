import 'package:flutter/material.dart';

class SalesPage extends StatelessWidget {
  final List<Map<String, String>> salesItems = [
    {
      'title': 'Winter Sale',
      'image': 'assets/sale1.jpg',
      'discount': '20% OFF'
    },
    {
      'title': 'Summer Collection',
      'image': 'assets/sale2.jpg',
      'discount': '15% OFF'
    },
    {'title': 'Flash Sale', 'image': 'assets/sale3.jpg', 'discount': '30% OFF'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sales', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
      ),
      backgroundColor: Colors.black,
      body: ListView.builder(
        itemCount: salesItems.length,
        itemBuilder: (context, index) {
          final item = salesItems[index];
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              alignment: Alignment.bottomLeft,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(item['image']!,
                      fit: BoxFit.cover, height: 200, width: double.infinity),
                ),
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius:
                          BorderRadius.only(bottomLeft: Radius.circular(8))),
                  child: Text(
                    '${item['title']} - ${item['discount']}',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
