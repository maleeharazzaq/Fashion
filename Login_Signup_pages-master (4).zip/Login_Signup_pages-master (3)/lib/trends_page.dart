import 'package:flutter/material.dart';

class TrendsPage extends StatelessWidget {
  // Mark the list literal as const.
  final List<Map<String, String>> trends = const [
    {'image': 'assets/trend1.jpg', 'title': 'Summer Streetwear'},
    {'image': 'assets/trend2.jpg', 'title': 'Classic Denim'},
    {'image': 'assets/trend3.jpg', 'title': 'Boho Chic'},
    {'image': 'assets/trend4.jpg', 'title': 'Modern Formals'},
    {'image': 'assets/trend5.jpg', 'title': 'Athleisure Looks'},
    {'image': 'assets/trend6.jpg', 'title': 'Casual Layers'},
  ];

  const TrendsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Trending Styles',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black,
        centerTitle: true,
      ),
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: GridView.builder(
          itemCount: trends.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.75,
          ),
          itemBuilder: (context, index) {
            final trend = trends[index];
            return TrendCard(
              imageUrl: trend['image']!,
              title: trend['title']!,
            );
          },
        ),
      ),
    );
  }
}

class TrendCard extends StatefulWidget {
  final String imageUrl;
  final String title;

  const TrendCard({super.key, required this.imageUrl, required this.title});

  @override
  _TrendCardState createState() => _TrendCardState();
}

class _TrendCardState extends State<TrendCard> {
  bool isLiked = false;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.black,
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Stack(
        children: [
          // Trend Image
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                widget.imageUrl,
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Gradient Overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withOpacity(0.7),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          // Title
          Positioned(
            bottom: 16,
            left: 12,
            right: 12,
            child: Text(
              widget.title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Like Button
          Positioned(
            top: 8,
            right: 8,
            child: GestureDetector(
              onTap: () {
                setState(() {
                  isLiked = !isLiked;
                });
              },
              child: Icon(
                isLiked ? Icons.favorite : Icons.favorite_border,
                color: isLiked ? Colors.red : Colors.white,
                size: 24,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
