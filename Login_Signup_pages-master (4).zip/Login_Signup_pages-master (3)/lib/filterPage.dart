import 'package:flutter/material.dart';

class FilterPage extends StatefulWidget {
  const FilterPage({super.key});

  @override
  _FilterPageState createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> {
  RangeValues _priceRange = const RangeValues(50, 500);
  bool _isOnSale = false;
  String _selectedCategory = 'All';
  String _selectedSortOption = 'Popularity';

  final List<String> _categories = [
    'All',
    'Clothing',
    'Footwear',
    'Accessories',
    'Electronics',
    'Beauty',
  ];

  final List<String> _sortOptions = [
    'Popularity',
    'Price: Low to High',
    'Price: High to Low',
    'Newest First',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Filters'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        actions: [
          TextButton(
            onPressed: () {
              // Apply filters logic here
            },
            child: const Text(
              'Apply',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Price Range Filter
            const Text('Price Range',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            RangeSlider(
              values: _priceRange,
              min: 0,
              max: 1000,
              divisions: 20,
              labels: RangeLabels(
                '\$${_priceRange.start.round()}',
                '\$${_priceRange.end.round()}',
              ),
              onChanged: (values) {
                setState(() {
                  _priceRange = values;
                });
              },
            ),
            const SizedBox(height: 20),

            // Category Filter
            const Text('Category',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            DropdownButton<String>(
              value: _selectedCategory,
              isExpanded: true,
              items: _categories.map((category) {
                return DropdownMenuItem(
                  value: category,
                  child: Text(category),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCategory = value!;
                });
              },
            ),
            const SizedBox(height: 20),

            // Sorting Options
            const Text('Sort By',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            DropdownButton<String>(
              value: _selectedSortOption,
              isExpanded: true,
              items: _sortOptions.map((sortOption) {
                return DropdownMenuItem(
                  value: sortOption,
                  child: Text(sortOption),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedSortOption = value!;
                });
              },
            ),
            const SizedBox(height: 20),

            // On Sale Filter
            SwitchListTile(
              title: const Text('On Sale'),
              value: _isOnSale,
              onChanged: (value) {
                setState(() {
                  _isOnSale = value;
                });
              },
            ),

            // Clear Filters Button
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _priceRange = const RangeValues(50, 500);
                  _isOnSale = false;
                  _selectedCategory = 'All';
                  _selectedSortOption = 'Popularity';
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey[800],
              ),
              child: const Text('Clear Filters'),
            ),
          ],
        ),
      ),
    );
  }
}
