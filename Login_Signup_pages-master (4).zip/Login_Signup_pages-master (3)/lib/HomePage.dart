import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Home Page Demo',
      theme: ThemeData(
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  // Example color palette based on neutral and warm tones
  static const Color _bgColor = Color(0xFFF5F5F5); // Light background
  static const Color _primaryColor = Color(0xFF000000); // Black for text
  static const Color _accentColor =
      Color(0xFFE49A3C); // Warm accent (brownish-gold)
  static const Color _greyColor = Color(0xFF9E9E9E);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      appBar: AppBar(
        backgroundColor: _bgColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.location_on),
          color: _primaryColor,
          onPressed: () {
            // Handle location action
          },
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Location',
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: _greyColor,
                    fontSize: 14,
                  ),
            ),
            Text(
              'New York, USA',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: _primaryColor,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            color: _primaryColor,
            onPressed: () {
              // Handle search action
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Banner / New Collection
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: _buildBanner(context),
            ),

            // Category Section
            Padding(
              padding:
                  const EdgeInsets.only(top: 24.0, left: 16.0, right: 16.0),
              child: _buildCategoryRow(context),
            ),

            // Flash Sale Section
            Padding(
              padding:
                  const EdgeInsets.only(top: 24.0, left: 16.0, right: 16.0),
              child: _buildFlashSaleSection(context),
            ),

            // Product Grid / Recommended Items
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: _buildRecommendedGrid(context),
            ),
          ],
        ),
      ),
    );
  }

  // --------------------------
  // BANNER SECTION (with solid color background)
  // --------------------------
  Widget _buildBanner(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _accentColor, // Using accent color as banner background
        borderRadius: BorderRadius.circular(12),
      ),
      height: 160,
      child: Container(
        // Dark overlay for contrast
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.black.withOpacity(0.35),
        ),
        child: Stack(
          children: [
            Positioned(
              left: 16,
              top: 16,
              right: 16,
              child: Text(
                'New Collection',
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ),
            Positioned(
              left: 16,
              bottom: 16,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accentColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                ),
                onPressed: () {
                  // Handle "Shop Now" action
                },
                child: const Text(
                  'Shop Now',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --------------------------
  // CATEGORY SECTION (using built-in icons)
  // --------------------------
  Widget _buildCategoryRow(BuildContext context) {
    final categories = [
      {'icon': Icons.category, 'name': 'All'},
      {'icon': Icons.new_releases, 'name': 'Newest'},
      {'icon': Icons.thumb_up, 'name': 'Popular'},
      {'icon': Icons.checkroom, 'name': 'Tops'},
      {'icon': Icons.shopping_bag, 'name': 'Pants'},
    ];

    return SizedBox(
      height: 80,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 16),
        itemBuilder: (context, index) {
          final cat = categories[index];
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: _accentColor.withOpacity(0.2),
                child: Icon(
                  cat['icon'] as IconData,
                  color: _primaryColor,
                  size: 24,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                cat['name'] as String,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: _primaryColor,
                      fontWeight: FontWeight.w500,
                    ),
              ),
            ],
          );
        },
      ),
    );
  }

  // --------------------------
  // FLASH SALE SECTION (using colored placeholders)
  // --------------------------
  Widget _buildFlashSaleSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Flash Sale',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: _primaryColor,
              ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 200,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: 5,
            separatorBuilder: (_, __) => const SizedBox(width: 16),
            itemBuilder: (context, index) {
              return _buildFlashSaleCard(index);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildFlashSaleCard(int index) {
    return Container(
      width: 140,
      decoration: BoxDecoration(
        color: _accentColor.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Stack(
        children: [
          Center(
            child: Text(
              'Item ${index + 1}',
              style: TextStyle(
                color: _primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Positioned(
            top: 8,
            right: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _accentColor,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                '-30%',
                style: TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --------------------------
  // RECOMMENDED / PRODUCT GRID (using placeholders)
  // --------------------------
  Widget _buildRecommendedGrid(BuildContext context) {
    final productList = [
      {'name': 'Light Brown Jacket', 'price': 83.97},
      {'name': 'Fleece Sweater', 'price': 75.00},
      {'name': 'Soft Sweater', 'price': 59.99},
      {'name': 'Wool Cardigan', 'price': 99.50},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recommended',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: _primaryColor,
              ),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: productList.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.7,
            mainAxisSpacing: 16,
            crossAxisSpacing: 16,
          ),
          itemBuilder: (context, index) {
            return _buildProductCard(productList[index], index);
          },
        ),
      ],
    );
  }

  Widget _buildProductCard(Map<String, Object> product, int index) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Placeholder for product image
          Container(
            height: 120,
            width: double.infinity,
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.3),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Center(
              child: Text(
                'Product ${index + 1}',
                style: TextStyle(
                  color: _primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              product['name'] as String,
              style: TextStyle(
                color: _primaryColor,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ),
          // Price + Add to Cart
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '\$${(product['price'] as double).toStringAsFixed(2)}',
                  style: TextStyle(
                    color: _primaryColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    // Handle add to cart action
                  },
                  icon: Icon(Icons.add_shopping_cart, color: _accentColor),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
