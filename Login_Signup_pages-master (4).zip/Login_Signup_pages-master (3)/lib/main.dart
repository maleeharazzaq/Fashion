import 'package:flutter/material.dart';
import 'WelcomeScreen.dart';
import 'SplashScreen.dart';
import 'QuestionnaireScreen.dart';
import 'loginScreen.dart';
//import 'regScreen.dart';
import 'HomePage.dart';
import 'sales_page.dart';
import 'trending_page.dart';
import 'trends_page.dart';
import 'favorites_page.dart';
import 'filterPage.dart';
import 'searchPage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi-Screen App',
      theme: ThemeData(
        // Enable Material 3 and set up a text theme
        useMaterial3: true,
        textTheme: const TextTheme(
          displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
          bodyLarge: TextStyle(fontSize: 16),
          headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const WelcomeScreen(),
        '/splash': (context) => SplashScreen(),
        '/questionnaire': (context) => QuestionnaireScreen(),
        '/login': (context) => const LoginScreen(),
        //'/register': (context) => regScreen(),
        '/home': (context) => const HomePage(),
        '/sales': (context) => SalesPage(),
        '/trending': (context) => TrendingPage(),
        '/trends': (context) => TrendsPage(),
        '/favorites': (context) => FavoritesPage(),
        '/filter': (context) => FilterPage(),
        '/search': (context) => SearchPage(),
      },
    );
  }
}
